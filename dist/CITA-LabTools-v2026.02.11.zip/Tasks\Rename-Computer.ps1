Write-Host "Rename task placeholder"
